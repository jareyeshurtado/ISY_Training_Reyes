#include <iostream>

using namespace std;

int main()
{
    cout << "Enter name: ";
    string name;
    cin >> name;
    cout << "Name is " << name << endl;
}
