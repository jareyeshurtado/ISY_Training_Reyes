
#include <iostream>
#include "cout.h"

// #ifndef USE_MY_COUT
// using namespace std;
// #else
// using namespace tass;
// #endif

//using namespace std;
using namespace tass;

int main()
{
    cout << "Test single string" << endl;
    cout << "Test with number: " <<  42 << endl;
    cout <<  42 << ": number before string" << endl;
}
