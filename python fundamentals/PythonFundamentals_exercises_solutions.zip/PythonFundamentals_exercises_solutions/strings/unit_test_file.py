#!/usr/bin/env python
"""Auto generated test module for: piglatin """

import unittest
import piglatin #pylint: disable=W0611

class Testpiglatin(unittest.TestCase):  #pylint: disable=R0904
    """
    Test class for piglatin
    """    def test_from_piglatin(self):"
                """ Testsfrom_piglatin"""'
                self.assertTrue(False)

    def test_to_piglatin(self):"
                """ Teststo_piglatin"""'
                self.assertTrue(False)

unittest.main()
